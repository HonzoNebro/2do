/** Automatically generated file. DO NOT MODIFY */
package com.ejemplo.t5_gestures;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}